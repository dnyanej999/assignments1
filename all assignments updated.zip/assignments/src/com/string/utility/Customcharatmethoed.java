package com.string.utility;

public class Customcharatmethoed 
{

	public static char myCharAt(int ind,String s)
	{
		char ar[]=s.toCharArray();
		
		return ar[ind] ;
	}
	
	
}
