package com.assignment.array;

import java.util.Set;
import java.util.TreeSet;

public class Task12sortarray 
{
public static void main(String[] args) 
{
int ar[]= {10,2,3,41,12,13,19,81,9,100};	
	
int resaray[]=new int[ar.length];
int ind=0;
	 for(int i = 0; i< 10; i++)
     {
		 for(int j = 0; j< ar.length; j++)
	     {
		       int no=ar[j];
		       int rem=no%10;
		       
		       if(rem==i)
		       {
		    	   resaray[ind]=ar[i];
		    	   ind++;
		       }
	     }
		 
     }

	 System.out.println("Before");
	 for(int val:ar)
	 {
		 System.out.print(val+" ");
	 }

	 System.out.println();
	 System.out.println("after");
	 for(int val:resaray)
	 {
		 System.out.print(val+" ");
	 }
}
}
