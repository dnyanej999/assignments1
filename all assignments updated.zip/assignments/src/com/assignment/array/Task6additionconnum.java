package com.assignment.array;

public class Task6additionconnum 
{
	public static void main(String[] args) 
	{
	int ar[]= {4,5,8,9,10};	
	int sum=0;
	
	 for(int i = 0; i + 1 < ar.length; i++)
     {
         // adding the alternate numbers
         sum = ar[i] + ar[i + 1];
         System.out.print(sum +" ");
     }
	}


}
