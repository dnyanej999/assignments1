package com.assignment.array;

import java.util.Set;
import java.util.TreeSet;

public class Task9arrangenum 
{
public static void main(String[] args)
{
		int ar[]= {1,5,3,7,9,10,15};	
		
		

}
}
