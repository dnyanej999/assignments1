package com.assignment.array;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Task10arrangelenofno 
{
public static void main(String[] args)
{
	int ar[]= {4443,54545,85,934,1};	
	
	Set<Integer> s=new TreeSet<Integer>();
	 for(int i = 0; i< ar.length; i++)
     {
		 s.add(ar[i]);
        
     }
	 System.out.println(s);
}
}
