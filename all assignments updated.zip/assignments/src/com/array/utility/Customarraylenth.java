package com.array.utility;

public class Customarraylenth 
{
public static int myarryalength(Object [] a)
{
	int count=0;
	for(Object obj:a)
	{
		count++;
	}
	return count;
}


private static int myarryalength(int[] a) 
{
	int count=0;
	for(int obj:a)
	{
		count++;
	}
	return count;	
}

private static int myarryalength(char[] a) 
{
	int count=0;
	for(char obj:a)
	{
		count++;
	}
	return count;	
}




}
