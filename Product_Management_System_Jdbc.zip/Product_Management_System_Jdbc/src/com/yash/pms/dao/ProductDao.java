package com.yash.pms.dao;

import java.sql.SQLException;
import java.util.List;

import com.yash.pms.model.Product;

public interface ProductDao {
	
	/**
	 * @param prod
	 * @return
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public int insertProduct(Product prod) throws SQLException, ClassNotFoundException;
	
	public List<Product> getAllProducts(int productId)  throws SQLException, ClassNotFoundException;
	
	public List<Product> updateProduct(Product prod)  throws SQLException, ClassNotFoundException;
	
	public List<Product> deleteProduct(int productId)  throws SQLException, ClassNotFoundException;

}
