package com.yash.pms.daoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.pms.dao.ProductDao;
import com.yash.pms.model.Product;
import com.yash.pms.utility.Utility;

public class ProductDaoImpl implements ProductDao {

	@Override
	public int insertProduct(Product prod) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		String INSERT_QUERY = "INSERT INTO PRODUCT1(PRODUCTID,PRODUCTNAME,PRICE,QUANTITY) VALUES(" + prod.getProductId()
				+ ",'" + prod.getProductName() + "'," + prod.getPrice() + "," + prod.getQuantity() + ")";

		PreparedStatement statement = Utility.getConnection().prepareStatement(INSERT_QUERY);
		return statement.executeUpdate();
	}

	public List<Product> getAllProducts(int productId) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		String SELECT_ALL_QUERY = "";
		if (productId == 0) {
			SELECT_ALL_QUERY = "SELECT * FROM PRODUCT1";
		} else {
			SELECT_ALL_QUERY = "SELECT * FROM PRODUCT1 WHERE PRODUCTID=" + productId;
		}

		PreparedStatement statement = Utility.getConnection().prepareStatement(SELECT_ALL_QUERY);
		ResultSet resultSet = statement.executeQuery();
		Product product = null;
		List<Product> productList = new ArrayList<>();
		while (resultSet.next()) {
			product = new Product();
			product.setProductId(resultSet.getInt("productId"));
			product.setProductName(resultSet.getString("productName").trim());
			product.setPrice(resultSet.getInt("price"));
			product.setQuantity(resultSet.getInt("quantity"));
			productList.add(product);

		}
		return productList;
	}

	@Override
	public List<Product> updateProduct(Product prod) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub

		List<Product> c = getAllProducts(prod.getProductId());
		if (!c.isEmpty()) {
			String UPDATE_QUERY = "UPDATE PRODUCT1 SET PRODUCTNAME='" + prod.getProductName() + "',PRICE="
					+ prod.getPrice() + ",QUANTITY=" + prod.getQuantity() + " WHERE PRODUCTID=" + prod.getProductId();

			PreparedStatement statement = Utility.getConnection().prepareStatement(UPDATE_QUERY);
			statement.executeUpdate();
		} else {
			System.out.println("Product not found !!");
		}

		return c;
	}

	@Override
	public List<Product> deleteProduct(int productId) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		List<Product> c = getAllProducts(productId);
		if (!c.isEmpty()) {
			String DELETE_QUERY = "DELETE FROM PRODUCT1 WHERE PRODUCTID=" + productId;

			PreparedStatement statement = Utility.getConnection().prepareStatement(DELETE_QUERY);
			statement.executeUpdate();
		} else {
			System.out.println("Product not found !!");
		}

		return c;
		
	}

}
