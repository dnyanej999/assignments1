package com.yash.pms.service;

public interface ProductService {

	public void insertProduct();

	public void displayProduct();

	public void searchProduct();

	public void updateProduct();

	public void deleteProduct();

}
