package com.yash.pms.utility;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.yash.pms.commen.Demologger;
import com.yash.pms.model.Customer;
import com.yash.pms.model.Product;

public class Globalstorage 
{
public static List<Customer> CUSTMER_LIST=new ArrayList<Customer>();
public static List<Product> PRODUCT_LIST=new ArrayList<Product>();

}
