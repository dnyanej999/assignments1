package com.yash.pms.daoimpl;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.yash.pms.commen.Demologger;
import com.yash.pms.dao.Customerdao;
import com.yash.pms.main.Application;
import com.yash.pms.model.Customer;
import com.yash.pms.utility.Globalstorage;

public class Customerimpl implements Customerdao 
{
	static Logger log= Logger.getLogger(Customerimpl.class);
	/*
	 * Customer CRUD Implementation 
	 */
	/*
	 * scanner object to get user input
	 */
	Scanner sc=new Scanner(System.in);
	
	/*
	 * logger reference for printing information on console
	 */

	/*
	 * Method to add customer in List
	 */
	@Override
	public String addCustomer() 
	{
		
		Customer c=new Customer();
		log.debug("====Enter custmer information=== ");
		
		log.info("Enter Custmer ID");
		int cid=sc.nextInt();
		c.setCustomerId(cid);
		
		Scanner sc1=new Scanner(System.in);

		log.info("Enter Custmer Name");
		String name=sc1.nextLine();
		c.setCustomerName(name);	
		
		Scanner sc2=new Scanner(System.in);

		log.info("Enter Custmer Address");
		String addr=sc2.nextLine();
		c.setAddress(addr);
		/*
		 * Accessing the Customer List form Utility package to add Customer Object
		 */
		Globalstorage.CUSTMER_LIST.add(c);
		log.info("customer added sucessfully");
		return null;
	}

	/*
	 * Method to View List of User by using for Each loop
	 */
	@Override
	public String viewCustomer() 
	{
	int ind=1;
	/*
	 * condition to validate Customer list Is Empty or not 
	 */
		if(Globalstorage.CUSTMER_LIST.isEmpty())
			log.info("List is empty");
		/*
		 * Retrieving data form Customer List
		 */
	for(Customer c :Globalstorage.CUSTMER_LIST)
	{
		log.info("==== Customer Information"+ ind +"==== ");
		log.info("Custmer ID ="+c.getCustomerId());
		log.info("Custmer Name ="+c.getCustomerName());
		log.info("Custmer Address ="+c.getAddress());
		ind++;
		
	}
		
		log.info("Info about Customer");
		return null;
	}

	/*
	 * Method to delete specific custmoer from list
	 */
	@Override
	public String deleteCustomer()
	{
		log.info("Enter CID to delete Customer");
		int cid=sc.nextInt();
		Customer c1=null;
		for(Customer c :Globalstorage.CUSTMER_LIST)
		{
			if(cid==c.getCustomerId())
			{
				c1=c;
				Globalstorage.CUSTMER_LIST.remove(c);
				break;
			}
		}
		log.info("Custmer ID ="+c1.getCustomerId());
		log.info("Custmer Name ="+c1.getCustomerName());
		log.info("Custmer Address ="+c1.getAddress());
		
		log.info("Customer Removed Sucessfully");
		return null;
	}

	/*
	 * Method to update specific Customer Name according to CID
	 */
	
	@Override
	public String updateCustomer()
	{
		Scanner sc2=new Scanner(System.in);


	
		log.info("Enter CID to Upadte Customer");
		
		int cid=sc.nextInt();
		Customer c1=null;
		for(Customer c :Globalstorage.CUSTMER_LIST)
		{
			if(cid==c.getCustomerId())
			{
				
				log.info("Enter Name to update");
				String name=sc2.nextLine();
				c.setCustomerName(name);
				c1=c;
				
			}
		}
		
		log.info("Custmer ID ="+c1.getCustomerId());
		log.info("Custmer Name ="+c1.getCustomerName());
		log.info("Custmer Address ="+c1.getAddress());
		
log.info("Customer Updated Sucessfully");
		
		return null;

	}

}
