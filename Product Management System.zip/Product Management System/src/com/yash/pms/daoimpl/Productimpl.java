package com.yash.pms.daoimpl;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.yash.pms.commen.Demologger;
import com.yash.pms.dao.Productdao;
import com.yash.pms.main.Application;
import com.yash.pms.model.Product;
import com.yash.pms.utility.Globalstorage;

public class Productimpl implements Productdao
{
	static Logger log= Logger.getLogger(Productimpl.class);

	/*
	 * Customer CRUD Implementation methods 
	 */
	
	/*
	 * scanner object to get user input
	 */
	
	Scanner sc=new Scanner(System.in);


	
	/*
	 * Method to add product in List
	 */
	
	@Override
	public String addProduct() 
	{
	
		Product p=new Product();
		log.debug("====Enter Product information====");
		
		log.info("Enter Product ID");
		int pid=sc.nextInt();
		p.setProductId(pid);
		
		Scanner sc1=new Scanner(System.in);

		log.info("Enter Product Name");
		String name=sc1.nextLine();
		p.setProductName(name);	
		
		Scanner sc2=new Scanner(System.in);

		log.info("Enter Product Product price");
		double price=sc2.nextDouble();
		p.setProdutPrice(price);
		
		log.info("Enter Product Product Quantity");
		int quantity=sc2.nextInt();
		p.setQuantity(quantity);
		
		
		Globalstorage.PRODUCT_LIST.add(p);
		log.info("product added sucessfully");
		return null;
	}

	/*
	 * Method to Retrieving product from List
	 */
	
	@Override
	public String viewProduct() {
		// TODO Auto-generated method stub
		int ind=1;
		if(Globalstorage.PRODUCT_LIST.isEmpty())
			log.info("List is empty");
		
	for(Product product :Globalstorage.PRODUCT_LIST)
	{
		log.info("==== Customer Information"+ ind +"==== ");
		log.info("product ID ="+product.getProductId());
		log.info("product Name ="+product.getProductName());
		log.info("product price ="+product.getProdutPrice());
		log.info("product quantity ="+product.getQuantity());
		
		ind++;
		
	}
		
		log.info("Info about Product");

		return null;
	}

	/*
	 * delete product from Product list
	 */
	@Override
	public String deleteProduct() 
	{
		// TODO Auto-generated method stub

		log.info("Enter PID to delete Product");
		int cid=sc.nextInt();
		Product p1=null;
		for(Product product :Globalstorage.PRODUCT_LIST)
		{
			if(cid==product.getProductId())
			{
				p1=product;
				Globalstorage.PRODUCT_LIST.remove(product);
				break;
			}
		}
		log.info("product ID ="+p1.getProductId());
		log.info("product Name ="+p1.getProductName());
		log.info("product price ="+p1.getProdutPrice());
		log.info("product Quantity ="+p1.getQuantity());
		
		
		log.info("Product Removed Sucessfully");

		return null;
	}

	/*
	 * method to update data
	 *  
	 */
	@Override
	public String updateProduct()
	{
		// TODO Auto-generated method stub
		Scanner sc2=new Scanner(System.in);


		
		log.info("Enter PID to Upadte Product");
		
		int pid=sc.nextInt();
		Product p1=null;
		for(Product product :Globalstorage.PRODUCT_LIST)
		{
			if(pid==product.getProductId())
			{
				
				log.info("Enter Name to update");
				String name=sc2.nextLine();
				product.setProductName(name);
				p1=product;
				
			}
		}
		
		log.info("product ID ="+p1.getProductId());
		log.info("product Name ="+p1.getProductName());
		log.info("product price ="+p1.getProdutPrice());
		log.info("product Quantity ="+p1.getQuantity());
		
        log.info("product Updated Sucessfully");

		return null;
	}

}
