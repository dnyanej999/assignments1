package com.yash.pms.exception;

public class InvalidData extends Exception
{
public InvalidData(String msg)
{
super(msg);	
}

}
