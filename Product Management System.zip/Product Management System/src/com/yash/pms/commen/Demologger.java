package com.yash.pms.commen;

import org.apache.log4j.Appender;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.SimpleLayout;

public class Demologger
{
	 Logger logger = Logger.getLogger(Demologger.class);
	  
	/*
	 *This methoed provied logger object with layout And Appender
	 */
	  public  Logger getLogObj()
	   {
		   Layout l=new SimpleLayout();
		   Appender ap=new ConsoleAppender(l);
		   
		   logger.addAppender(ap);
		   logger.info("mylogger");
		   
		   return logger;
		   
	   }
}
