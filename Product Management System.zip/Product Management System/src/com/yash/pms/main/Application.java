package com.yash.pms.main;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.yash.pms.commen.Demologger;
import com.yash.pms.daoimpl.Customerimpl;
import com.yash.pms.daoimpl.Productimpl;

public class Application 
{
	static Logger log= Logger.getLogger(Application.class);
public static void main(String[] args) 
{	

	

Customerimpl c=new Customerimpl();
Productimpl p=new Productimpl();


Scanner sc=new Scanner(System.in);

log.info("Press 1.product");
log.info("Press 2.Customer");

int option=sc.nextInt();
if(option==1)
{
	while (true)
	{
	log.info("Enter your choice \n 1.add Product \n 2.view Product \n 3.update Product \n 4.delete Product \n 5.Exit");
Scanner sc1=new Scanner(System.in);
	String KEY=sc1.nextLine();
	switch (KEY)
	{
	case "1":
		p.addProduct();
		break;

	case "2":
		p.viewProduct();
		break;

	case "3":
		p.updateProduct();
		break;

	case "4":
		p.deleteProduct();
		break;

	case "5":
		log.info("visit again ...thank you.");
		System.exit(0);
		break;

	default:
		log.info("Invalid choice");
		break;
	}


	}
	
}
else if(option==2)
{
while (true)
{
log.info("Enter your choice \n 1.addcustomer \n 2.view customer \n 3.update customer \n 4.delete customer \n 5.Exit");

String KEY=sc.nextLine();
switch (KEY)
{
case "1":
	c.addCustomer();
	break;

case "2":
	c.viewCustomer();
	break;

case "3":
	c.updateCustomer();
	break;

case "4":
	c.deleteCustomer();
	break;

case "5":
	log.info("visit again ...thank you.");
	System.exit(0);
	break;

default:
	log.info("Invalid choice");
	break;
}


}
}

}
}
