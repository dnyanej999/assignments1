package com.yash.pms.dao;

public interface Productdao {
	
	/*
	 * Product model CRUD Methods
	 */
	String addProduct();
	String viewProduct();
	String deleteProduct();
	String updateProduct();
	
}
