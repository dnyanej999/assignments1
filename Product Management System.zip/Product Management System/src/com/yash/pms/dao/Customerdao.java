package com.yash.pms.dao;

public interface Customerdao 
{
	/*
	 * Customer Model CRUD Methods 
	 */
String addCustomer();
String viewCustomer();
String deleteCustomer();
String updateCustomer();
}
