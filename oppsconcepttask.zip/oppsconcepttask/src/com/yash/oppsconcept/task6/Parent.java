package com.yash.oppsconcept.task6;

public class Parent 
{
	
public void comprestring(String s1,String s2)
{
	
	if(s1.equalsIgnoreCase(s2))
		System.out.println("both are equals");
}

}
