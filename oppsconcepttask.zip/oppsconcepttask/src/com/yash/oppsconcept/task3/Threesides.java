package com.yash.oppsconcept.task3;

import java.util.Scanner;

public class Threesides 
{


	public void area(int side1,int side2,int side3)
	{
		int area1=side1*side2;
	System.out.println("area of reactangle ="+area1);
	}
		
	
}
