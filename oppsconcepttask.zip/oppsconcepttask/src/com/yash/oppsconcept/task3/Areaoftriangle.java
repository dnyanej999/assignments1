package com.yash.oppsconcept.task3;

public class Areaoftriangle
{


	public void area(int side1,int side2,int side3)
	{
		
	System.out.println("Area of Triangle ="+(side1*side2)/2);
	}
	
}
