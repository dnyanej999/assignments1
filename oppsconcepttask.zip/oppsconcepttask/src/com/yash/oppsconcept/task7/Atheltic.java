package com.yash.oppsconcept.task7;

public class Atheltic 
{
	int aid;
	String aname, address, dob;
}
