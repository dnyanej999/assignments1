package com.yash.oppsconcept.task1;

public class Fruit 
{
	String fruitname;
	String  fruitcolor;
	public Fruit(String fruitname, String fruitcolor) {
		super();
		this.fruitname = fruitname;
		this.fruitcolor = fruitcolor;
	}
	
}
