package com.yash.oppsconcept.task2;

public class Sphere  implements Shape
{

	@Override
	public double area(double arearofcircle)
	{
		
	return 4*(3.14*(arearofcircle*arearofcircle));
	}
	
}
