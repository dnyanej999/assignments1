package com.yash.oppsconcept.task2;

public interface Shape 
{
	
double area(double area);

}
