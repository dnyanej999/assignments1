package com.yash.oppsconcept.task2;

public class Circle implements Shape
{

	@Override
	public double area(double arearofcircle)
	{
		
	return 3.14*(arearofcircle*arearofcircle);
	}

}
